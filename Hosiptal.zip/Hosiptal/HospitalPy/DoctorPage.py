from tkinter import *
from tkinter.ttk import Separator
import ConnectSQL
from image import get_image

def doctor():
    doctor_page = Tk()  # 创建一个医生窗口对象
    doctor_page.title('Hospital Management System - Doctor')  # 给窗口命名
    doctor_page.geometry('800x500')  # 定义窗口的长宽，geometry方法中传入字符串参数，字符串中应为长x宽（Note:x是小写字母x)

    doctor_page.resizable(False, False)  # 不允许调整窗口大小
    canvas_root = Canvas(doctor_page, bg='white', width=800, height=500)
    im_root = get_image('login.jpg', 780, 480)
    canvas_root.create_image(400, 250, image=im_root)
    canvas_root.pack()

    # 两条分割线将页面分成三块，上部对病人增删改查，中部对病房，下部用药
    sep1 = Separator(doctor_page, orient=HORIZONTAL)  # VERTICAL为竖的分割线
    sep1.place(relx=0, rely=0.33, relwidth=1.0, relheight=0.01)

    sep2 = Separator(doctor_page, orient=HORIZONTAL)  # VERTICAL为竖的分割线
    sep2.place(relx=0, rely=0.66, relwidth=1.0, relheight=0.01)

    # 对病人的操作分区
    patient_name_label = Label(doctor_page, text='病人姓名:', font=('隶书', 14))
    patient_name_label.place(relx=0.05, rely=0.04)
    patient_name_entry = Entry(doctor_page)
    patient_name_entry.place(relx=0.23, rely=0.04, relwidth=0.25)

    patient_id_label = Label(doctor_page, text='病人身份证号:', font=('隶书', 14))
    patient_id_label.place(relx=0.05, rely=0.14)
    patient_id_entry = Entry(doctor_page)
    patient_id_entry.place(relx=0.23, rely=0.14, relwidth=0.25)

    patient_age_label = Label(doctor_page, text='病人年龄:', font=('隶书', 14))
    patient_age_label.place(relx=0.05, rely=0.24)
    patient_age_entry = Entry(doctor_page)
    patient_age_entry.place(relx=0.23, rely=0.24, relwidth=0.25)

    all_patient_bt = Button(doctor_page, text="查看所有病人", command=show_all_patient)
    all_patient_bt.place(relx=0.55, rely=0.04, relwidth=0.15, relheight=0.08)

    name_patient_bt = Button(doctor_page, text="按姓名查找", command=lambda: search_patient_name(patient_name_entry.get()))
    name_patient_bt.place(relx=0.55, rely=0.14, relwidth=0.15, relheight=0.08)

    id_patient_bt = Button(doctor_page, text="按身份证号查找", command=lambda: search_patient_id(patient_id_entry.get()))
    id_patient_bt.place(relx=0.55, rely=0.24, relwidth=0.15, relheight=0.08)

    add_patient_bt = Button(doctor_page, text="添加病人", command=lambda: add_patient(patient_id_entry.get(),
                                                                                  patient_name_entry.get(),
                                                                                  patient_age_entry.get()))
    add_patient_bt.place(relx=0.75, rely=0.04, relwidth=0.15, relheight=0.08)

    delete_patient_bt = Button(doctor_page, text="删除病人(id)", command=lambda: delete_patient(patient_id_entry.get()))
    delete_patient_bt.place(relx=0.75, rely=0.14, relwidth=0.15, relheight=0.08)

    add_patient_doctor_bt = Button(doctor_page, text="添加/改变主治医生",
                                   command=lambda: add_patient_doctor(patient_id_entry.get(), main_doctor_entry.get()))
    add_patient_doctor_bt.place(relx=0.75, rely=0.24, relwidth=0.15, relheight=0.08)

    # 对病房的操作分区
    ward_number_label = Label(doctor_page, text='病房号:', font=('隶书', 14))
    ward_number_label.place(relx=0.05, rely=0.37)
    ward_number_entry = Entry(doctor_page)
    ward_number_entry.place(relx=0.23, rely=0.37, relwidth=0.25)

    ward_department_label = Label(doctor_page, text='所属科室:', font=('隶书', 14))
    ward_department_label.place(relx=0.05, rely=0.47)
    ward_department_entry = Entry(doctor_page)
    ward_department_entry.place(relx=0.23, rely=0.47, relwidth=0.25)

    ward_capacity_label = Label(doctor_page, text='病床数:', font=('隶书', 14))
    ward_capacity_label.place(relx=0.05, rely=0.57)
    ward_capacity_entry = Entry(doctor_page)
    ward_capacity_entry.place(relx=0.23, rely=0.57, relwidth=0.25)

    all_ward_bt = Button(doctor_page, text="查看所有病房", command=show_all_ward)
    all_ward_bt.place(relx=0.55, rely=0.37, relwidth=0.15, relheight=0.08)

    rest_ward_bt = Button(doctor_page, text="查看空余病房", command=show_rest_ward)
    rest_ward_bt.place(relx=0.55, rely=0.47, relwidth=0.15, relheight=0.08)

    department_ward_bt = Button(doctor_page, text="按科室查看病房",
                                command=lambda: search_ward_department(ward_department_entry.get()))
    department_ward_bt.place(relx=0.55, rely=0.57, relwidth=0.15, relheight=0.08)

    inward_bt = Button(doctor_page, text="病人入院", command=lambda: patient_in(patient_id_entry.get(),
                                                                            ward_number_entry.get()))
    inward_bt.place(relx=0.75, rely=0.37, relwidth=0.15, relheight=0.08)

    outward_bt = Button(doctor_page, text="病人出院", command=lambda: patient_out(patient_id_entry.get()))
    outward_bt.place(relx=0.75, rely=0.47, relwidth=0.15, relheight=0.08)

    # 对药品的操作分区
    medicine_name_label = Label(doctor_page, text='药品名:', font=('隶书', 14))
    medicine_name_label.place(relx=0.05, rely=0.7)
    medicine_name_entry = Entry(doctor_page)
    medicine_name_entry.place(relx=0.23, rely=0.7, relwidth=0.25)

    medicine_price_label = Label(doctor_page, text='药品价格:', font=('隶书', 14))
    medicine_price_label.place(relx=0.05, rely=0.8)
    medicine_price_entry = Entry(doctor_page)
    medicine_price_entry.place(relx=0.23, rely=0.8, relwidth=0.25)

    main_doctor_label = Label(doctor_page, text='主治医生:', font=('隶书', 14))
    main_doctor_label.place(relx=0.05, rely=0.9)
    main_doctor_entry = Entry(doctor_page)
    main_doctor_entry.place(relx=0.23, rely=0.9, relwidth=0.25)

    all_medicine_bt = Button(doctor_page, text="查看所有药品", command=show_all_medicine)
    all_medicine_bt.place(relx=0.55, rely=0.7, relwidth=0.15, relheight=0.08)

    name_medicine_bt = Button(doctor_page, text="按名称查找药品",
                              command=lambda: search_medicine_name(medicine_name_entry.get()))
    name_medicine_bt.place(relx=0.55, rely=0.8, relwidth=0.15, relheight=0.08)

    use_medicine_bt = Button(doctor_page, text="病人用药",
                             command=lambda: use_medicine(patient_id_entry.get(), medicine_name_entry.get()))
    use_medicine_bt.place(relx=0.75, rely=0.7, relwidth=0.15, relheight=0.08)

    doctor_page.mainloop()  # mainloop实际上是使用while循环实现的，因为窗口的内容是会动态变化的


def show_all_patient():
    result_page = Tk()
    result_page.title('查询结果')  # 给窗口命名
    result_page.geometry('400x500')
    sql_str = 'select * from patientview'
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    result = hospital.search_all(sql_str)
    result_txt = Text(result_page)
    result_txt.insert(END, "身份证号\t姓名\t年龄\t费用\t病房\t主治医生\n")
    for i in result:
        for j in i:
            result_txt.insert(END, j)
            result_txt.insert(END, "\t")
        result_txt.insert(END, "\n")
    result_txt.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)

    result_page.mainloop()


def search_patient_name(name):
    result_page = Tk()
    result_page.title('查询结果')  # 给窗口命名
    result_page.geometry('400x500')
    sql_str = "select * from patientview where Name = '" + name + "'"
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    result = hospital.search_all(sql_str)
    result_txt = Text(result_page)
    result_txt.insert(END, "身份证号\t姓名\t年龄\t费用\t病房\t主治医生\n")
    for i in result:
        for j in i:
            result_txt.insert(END, j)
            result_txt.insert(END, "\t")
        result_txt.insert(END, "\n")
    result_txt.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)

    result_page.mainloop()


def search_patient_id(patient_id):
    result_page = Tk()
    result_page.title('查询结果')  # 给窗口命名
    result_page.geometry('400x500')
    sql_str = "select * from patientview where ID = '" + patient_id + "'"
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    result = hospital.search_all(sql_str)
    result_txt = Text(result_page)
    result_txt.insert(END, "身份证号\t姓名\t年龄\t费用\t病房\t主治医生\n")
    for i in result:
        for j in i:
            result_txt.insert(END, j)
            result_txt.insert(END, "\t")
        result_txt.insert(END, "\n")
    result_txt.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)

    result_page.mainloop()


def show_all_ward():
    result_page = Tk()
    result_page.title('查询结果')  # 给窗口命名
    result_page.geometry('400x500')
    sql_str = 'SELECT ward.WardNumber,department.DepartmentName,ward.Capacity,' \
              'ward.Rest FROM ward INNER JOIN department ON ward.Department = department.DepartmentNumber'
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    result = hospital.search_all(sql_str)
    result_txt = Text(result_page)
    result_txt.insert(END, "病房号\t所属科室\t总床位\t空余床位\n")
    for i in result:
        for j in i:
            result_txt.insert(END, j)
            result_txt.insert(END, "\t")
        result_txt.insert(END, "\n")
    result_txt.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)

    result_page.mainloop()


def show_rest_ward():
    result_page = Tk()
    result_page.title('查询结果')  # 给窗口命名
    result_page.geometry('400x500')
    sql_str = "SELECT ward.WardNumber,department.DepartmentName,ward.Capacity," \
              "ward.Rest FROM ward INNER JOIN department ON ward.Department = department.DepartmentNumber " \
              "WHERE ward.Rest>0"

    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    result = hospital.search_all(sql_str)
    result_txt = Text(result_page)
    result_txt.insert(END, "病房号\t所属科室\t总床位\t空余床位\n")
    for i in result:
        for j in i:
            result_txt.insert(END, j)
            result_txt.insert(END, "\t")
        result_txt.insert(END, "\n")
    result_txt.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)

    result_page.mainloop()


def show_all_medicine():
    result_page = Tk()
    result_page.title('查询结果')  # 给窗口命名
    result_page.geometry('400x500')
    sql_str = 'SELECT * from medicine '
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    result = hospital.search_all(sql_str)
    result_txt = Text(result_page)
    result_txt.insert(END, "药品编号\t\t药品名称\t\t价格\n")
    for i in result:
        for j in i:
            result_txt.insert(END, j)
            result_txt.insert(END, "\t\t")
        result_txt.insert(END, "\n")
    result_txt.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)

    result_page.mainloop()


def search_ward_department(department):
    result_page = Tk()
    result_page.title('查询结果')  # 给窗口命名
    result_page.geometry('400x500')
    sql_str = "SELECT ward.WardNumber,department.DepartmentName,ward.Capacity," \
              "ward.Rest FROM ward INNER JOIN department ON ward.Department = department.DepartmentNumber " \
              "WHERE department.DepartmentName=\'" + department + " ' "
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    result = hospital.search_all(sql_str)
    result_txt = Text(result_page)
    result_txt.insert(END, "病房号\t所属科室\t总床位\t空余床位\n")
    for i in result:
        for j in i:
            result_txt.insert(END, j)
            result_txt.insert(END, "\t")
        result_txt.insert(END, "\n")
    result_txt.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)

    result_page.mainloop()


def search_medicine_name(name):
    result_page = Tk()
    result_page.title('查询结果')  # 给窗口命名
    result_page.geometry('400x500')
    sql_str = "SELECT * FROM medicine WHERE MedicineName='"+name+"'"
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    result = hospital.search_all(sql_str)
    result_txt = Text(result_page)
    result_txt.insert(END, "药品编号\t\t药品名称\t\t价格\n")
    for i in result:
        for j in i:
            result_txt.insert(END, j)
            result_txt.insert(END, "\t\t")
        result_txt.insert(END, "\n")
    result_txt.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)

    result_page.mainloop()


def delete_patient(patient_id):
    sql_str = "DELETE FROM patient WHERE PatientID = " + patient_id
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    hospital.delete_one(sql_str)


def use_medicine(patient, medicine):
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    hospital.call_use_medicine(patient, medicine)


def add_patient(patient_id, patient_name, patient_age):
    if int(patient_id) < 100000 or int(patient_id) > 999999:  # 输入不符合要求，不执行插入操作
        result_page = Tk()
        result_page.title('提示')  # 给窗口命名
        result_page.geometry('300x200')
        insert_fail = Label(result_page, text='请输入正确的身份证号', font=('Arial', 15))
        insert_fail.place(relx=0.1, rely=0.2, relwidth=0.8, relheight=0.6)
        result_page.mainloop()

    # sql语句：INSERT INTO patient VALUES (patient_id, 'patient_name', patient_age, 0);
    sql_str = "INSERT INTO patient VALUES ("+patient_id+", '" + patient_name+"', "+patient_age+", 0)"
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    hospital.insert_one(sql_str)


def add_patient_doctor(patient_id, doctor_id):
    # sql语句：UPDATE patientdoctor SET DoctorID = doctor_id WHERE PatientID = patient_id
    sql_str = "UPDATE patientdoctor SET DoctorID = " + doctor_id + " WHERE PatientID = " + patient_id
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    hospital.updata_one(sql_str)


def patient_in(patient_id, ward):
    # sql语句：UPDATE inpatient SET WardNumber = ward WHERE PatientID = patient_id
    sql_str = "UPDATE inpatient SET WardNumber = " + ward + " WHERE PatientID = " + patient_id
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    hospital.updata_one(sql_str)


def patient_out(patient_id):
    # sql语句：UPDATE inpatient SET WardNumber = 0 WHERE PatientID = patient_id
    sql_str = "UPDATE inpatient SET WardNumber = 0 WHERE PatientID = " + patient_id
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    hospital.updata_one(sql_str)