import ConnectSQL
str = "甲一"
sqlstr = "select * from patient where PatientName = '" + str +"'"
DB = ConnectSQL.MysqlConn()
DB.__init__()
result = DB.search_all(sqlstr)
print(result)