from tkinter import *
import DoctorPage
import ManagerPage
from image import get_image


def login():
    login_page = Tk()  # 创建一个登录窗口对象
    login_page.title('Hospital Management System')  # 给窗口命名
    login_page.geometry('500x300')  # 定义窗口的长宽，geometry方法中传入字符串参数，字符串中应为长x宽（Note:x是小写字母x)
    login_page.resizable(False, False)  # 不允许调整窗口大小
    # 接下来是背景图片设置
    canvas_root = Canvas(login_page, bg='white', width=500, height=300)
    im_root = get_image('login.jpg', 450, 275)
    canvas_root.create_image(250, 150, image=im_root)
    canvas_root.pack()

    # 定义欢迎标签
    # Label(master = None, cnf = {}, **kw), kw参数是类似dict一样接收label组件定义的键值对
    welcome_lb = Label(login_page, text='Welcome to hospital management system!', font=('Arial', 15))
    welcome_lb.place(relx=0.1, rely=0.05, relwidth=0.8, relheight=0.1)

    # 定义选择身份标签
    # Label(master = None, cnf = {}, **kw), kw参数是类似dict一样接收label组件定义的键值对
    choose_lb = Label(login_page, text='请选择您的登陆身份', font=('Arial', 15))
    choose_lb.place(relx=0.3, rely=0.2, relwidth=0.4, relheight=0.1)

    # 定义医生登录按钮，点击后进入DoctorPage
    doctor_button = Button(login_page, text="医生", command=lambda: [login_page.destroy(), DoctorPage.doctor()])
    doctor_button.place(relx=0.1, rely=0.6, relwidth=0.2, relheight=0.1)

    # 定义管理员登录按钮，点击后进入ManagerPage
    manager_button = Button(login_page, text="管理员", command=lambda: [login_page.destroy(), ManagerPage.manager()])
    manager_button.place(relx=0.7, rely=0.6, relwidth=0.2, relheight=0.1)

    login_page.mainloop()  # mainloop实际上是使用while循环实现的，因为窗口的内容是会动态变化的


login()
