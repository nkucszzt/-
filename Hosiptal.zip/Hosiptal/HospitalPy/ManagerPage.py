from tkinter import *
from tkinter.ttk import Separator
import ConnectSQL
from image import get_image


def manager():
    manager_page = Tk()  # 创建一个管理员窗口对象
    manager_page.title('Hospital Management System - manager')  # 给窗口命名
    manager_page.geometry('800x500')  # 定义窗口的长宽，geometry方法中传入字符串参数，字符串中应为长x宽（Note:x是小写字母x)

    manager_page.resizable(False, False)  # 不允许调整窗口大小
    canvas_root = Canvas(manager_page, bg='white', width=800, height=500)
    im_root = get_image('login.jpg', 780, 480)
    canvas_root.create_image(400, 250, image=im_root)
    canvas_root.pack()

    # 两条分割线将页面分成三块，上部对病人增删改查，中部对病房，下部用药
    sep1 = Separator(manager_page, orient=HORIZONTAL)  # VERTICAL为竖的分割线
    sep1.place(relx=0, rely=0.33, relwidth=1.0, relheight=0.01)

    sep2 = Separator(manager_page, orient=HORIZONTAL)  # VERTICAL为竖的分割线
    sep2.place(relx=0, rely=0.66, relwidth=1.0, relheight=0.01)

    # 对部门的操作分区
    department_name_label = Label(manager_page, text='科室名称:', font=('隶书', 14))
    department_name_label.place(relx=0.05, rely=0.04)
    department_name_entry = Entry(manager_page)
    department_name_entry.place(relx=0.23, rely=0.04, relwidth=0.25)

    doctor_name_label = Label(manager_page, text='医生姓名:', font=('隶书', 14))
    doctor_name_label.place(relx=0.05, rely=0.14)
    doctor_name_entry = Entry(manager_page)
    doctor_name_entry.place(relx=0.23, rely=0.145, relwidth=0.25)

    doctor_level_label = Label(manager_page, text='医生职称:', font=('隶书', 14))
    doctor_level_label.place(relx=0.05, rely=0.25)
    doctor_level_entry = Entry(manager_page)
    doctor_level_entry.place(relx=0.23, rely=0.255, relwidth=0.25)

    all_department_bt = Button(manager_page, text="查看所有科室", command=show_all_department)
    all_department_bt.place(relx=0.55, rely=0.03, relwidth=0.15, relheight=0.08)

    name_department_bt = Button(manager_page, text="按名称查找科室",
                                command=lambda: search_department_name(department_name_entry.get()))
    name_department_bt.place(relx=0.55, rely=0.13, relwidth=0.15, relheight=0.08)


    set_head_bt = Button(manager_page, text="设为科室负责人(nd)", command=lambda: set_head(department_name_entry.get(),
                                                                                doctor_name_entry.get()))
    set_head_bt.place(relx=0.55, rely=0.24, relwidth=0.15, relheight=0.08)

    add_doctor_bt = Button(manager_page, text="新增医生(id)", command=lambda: add_doctor(doctor_name_entry .get(),
                                                                                 doctor_level_entry.get(),
                                                                                 department_name_entry.get()))
    add_doctor_bt.place(relx=0.75, rely=0.03, relwidth=0.15, relheight=0.08)

    delete_doctor_bt = Button(manager_page, text="删除医生(id)", command=lambda: delete_doctor(doctor_name_entry.get()))
    delete_doctor_bt.place(relx=0.75, rely=0.13, relwidth=0.15, relheight=0.08)

    update_doctor_bt = Button(manager_page, text="查看所有医生", command=show_all_doctor)
    update_doctor_bt.place(relx=0.75, rely=0.24, relwidth=0.15, relheight=0.08)

    # 对病房的操作分区
    ward_number_label = Label(manager_page, text='病房号:', font=('隶书', 14))
    ward_number_label.place(relx=0.05, rely=0.37)
    ward_number_entry = Entry(manager_page)
    ward_number_entry.place(relx=0.23, rely=0.37, relwidth=0.25)

    ward_department_label = Label(manager_page, text='所属科室:', font=('隶书', 14))
    ward_department_label.place(relx=0.05, rely=0.47)
    ward_department_entry = Entry(manager_page)
    ward_department_entry.place(relx=0.23, rely=0.47, relwidth=0.25)

    ward_capacity_label = Label(manager_page, text='病床数:', font=('隶书', 14))
    ward_capacity_label.place(relx=0.05, rely=0.57)
    ward_capacity_entry = Entry(manager_page)
    ward_capacity_entry.place(relx=0.23, rely=0.57, relwidth=0.25)

    all_ward_bt = Button(manager_page, text="查看所有病房", command=show_all_ward)
    all_ward_bt.place(relx=0.55, rely=0.37, relwidth=0.15, relheight=0.08)

    department_ward_bt = Button(manager_page, text="按科室查看病房",
                                command=lambda: search_ward_department(ward_department_entry.get()))
    department_ward_bt.place(relx=0.55, rely=0.47, relwidth=0.15, relheight=0.08)

    add_ward_bt = Button(manager_page, text="新增病房(id)", command=lambda: add_ward(ward_number_entry.get(),
                                                                             ward_capacity_entry.get(),
                                                                             ward_department_entry.get()))
    add_ward_bt.place(relx=0.75, rely=0.37, relwidth=0.15, relheight=0.08)

    delete_ward_bt = Button(manager_page, text="删除病房(id)", command=lambda: delete_ward(ward_number_entry.get()))
    delete_ward_bt.place(relx=0.75, rely=0.47, relwidth=0.15, relheight=0.08)

    # 对药品的操作分区
    medicine_name_label = Label(manager_page, text='药品名:', font=('隶书', 14))
    medicine_name_label.place(relx=0.05, rely=0.7)
    medicine_name_entry = Entry(manager_page)
    medicine_name_entry.place(relx=0.23, rely=0.7, relwidth=0.25)

    medicine_price_label = Label(manager_page, text='药品价格:', font=('隶书', 14))
    medicine_price_label.place(relx=0.05, rely=0.8)
    medicine_price_entry = Entry(manager_page)
    medicine_price_entry.place(relx=0.23, rely=0.8, relwidth=0.25)

    all_medicine_bt = Button(manager_page, text="查看所有药品", command=show_all_medicine)
    all_medicine_bt.place(relx=0.55, rely=0.7, relwidth=0.15, relheight=0.08)

    name_medicine_bt = Button(manager_page, text="按名称查找药品",
                              command=lambda: search_medicine_name(medicine_name_entry.get()))
    name_medicine_bt.place(relx=0.55, rely=0.8, relwidth=0.15, relheight=0.08)

    add_medicine_bt = Button(manager_page, text="新增药品", command=lambda: add_medicine(medicine_name_entry.get(),
                                                                                     medicine_price_entry.get()))
    add_medicine_bt.place(relx=0.75, rely=0.7, relwidth=0.15, relheight=0.08)

    delete_medicine_bt = Button(manager_page, text="删除药品(id)", command=lambda: delete_medicine(medicine_name_entry.get()))
    delete_medicine_bt.place(relx=0.75, rely=0.8, relwidth=0.15, relheight=0.08)

    update_medicine_bt = Button(manager_page, text="更新药品", command=lambda: update_medicine(medicine_name_entry.get(),
                                                                                           medicine_price_entry.get()))
    update_medicine_bt.place(relx=0.75, rely=0.9, relwidth=0.15, relheight=0.08)

    manager_page.mainloop()  # mainloop实际上是使用while循环实现的，因为窗口的内容是会动态变化的


def show_all_department():
    result_page = Tk()
    result_page.title('查询结果')  # 给窗口命名
    result_page.geometry('400x500')
    sql_str = "SELECT department.DepartmentNumber, department.DepartmentName, doctor.DoctorName FROM department " \
              ", doctor WHERE department.DepartmentHead = doctor.DoctorNumber "
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    result = hospital.search_all(sql_str)
    result_txt = Text(result_page)
    result_txt.insert(END, "科室编号\t\t科室名\t\t负责人\n")
    for i in result:
        for j in i:
            result_txt.insert(END, j)
            result_txt.insert(END, "\t\t")
        result_txt.insert(END, "\n")
    result_txt.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)

    result_page.mainloop()


def search_department_name(name):
    result_page = Tk()
    result_page.title('查询结果')  # 给窗口命名
    result_page.geometry('400x500')
    sql_str = "SELECT department.DepartmentNumber, department.DepartmentName, doctor.DoctorName FROM department " \
              ", doctor WHERE department.DepartmentHead = doctor.DoctorNumber AND department.DepartmentName = '" \
              + name + "'"
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    result = hospital.search_all(sql_str)
    result_txt = Text(result_page)
    if result :
        result_txt.insert(END, "科室编号\t\t科室名\t\t负责人\n")
        for i in result:
            for j in i:
                result_txt.insert(END, j)
                result_txt.insert(END, "\t\t")
            result_txt.insert(END, "\n")
        result_txt.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)
    else:
        result_txt.insert(END, "无结果")
        result_txt.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)
    result_page.mainloop()


def show_all_ward():
    result_page = Tk()
    result_page.title('查询结果')  # 给窗口命名
    result_page.geometry('400x500')
    sql_str = 'SELECT ward.WardNumber,department.DepartmentName,ward.Capacity,' \
              'ward.Rest FROM ward INNER JOIN department ON ward.Department = department.DepartmentNumber ' \
              'ORDER BY ward.WardNumber ASC'
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    result = hospital.search_all(sql_str)
    result_txt = Text(result_page)
    result_txt.insert(END, "病房号\t所属科室\t总床位\t空余床位\n")
    for i in result:
        for j in i:
            result_txt.insert(END, j)
            result_txt.insert(END, "\t")
        result_txt.insert(END, "\n")
    result_txt.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)

    result_page.mainloop()


def search_ward_department(department):
    result_page = Tk()
    result_page.title('查询结果')  # 给窗口命名
    result_page.geometry('400x500')
    sql_str = "SELECT ward.WardNumber,department.DepartmentName,ward.Capacity, " \
              "ward.Rest FROM ward INNER JOIN department ON ward.Department = department.DepartmentNumber " \
              "WHERE department.DepartmentName='" + department + "'"
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    result = hospital.search_all(sql_str)
    result_txt = Text(result_page)
    result_txt.insert(END, "病房号\t所属科室\t总床位\t空余床位\n")
    for i in result:
        for j in i:
            result_txt.insert(END, j)
            result_txt.insert(END, "\t")
        result_txt.insert(END, "\n")
    result_txt.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)

    result_page.mainloop()


def search_medicine_name(name):
    result_page = Tk()
    result_page.title('查询结果')  # 给窗口命名
    result_page.geometry('400x500')
    sql_str = "SELECT * FROM medicine WHERE MedicineName='"+name+"'"
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    result = hospital.search_all(sql_str)
    result_txt = Text(result_page)
    result_txt.insert(END, "药品编号\t\t药品名称\t\t价格\n")
    for i in result:
        for j in i:
            result_txt.insert(END, j)
            result_txt.insert(END, "\t\t")
        result_txt.insert(END, "\n")
    result_txt.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)

    result_page.mainloop()


def show_all_medicine():
    result_page = Tk()
    result_page.title('查询结果')  # 给窗口命名
    result_page.geometry('400x500')
    sql_str = 'SELECT * from medicine '
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    result = hospital.search_all(sql_str)
    result_txt = Text(result_page)
    result_txt.insert(END, "药品编号\t\t药品名称\t\t价格\n")
    for i in result:
        for j in i:
            result_txt.insert(END, j)
            result_txt.insert(END, "\t\t")
        result_txt.insert(END, "\n")
    result_txt.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)

    result_page.mainloop()


def delete_patient(patient_id):
    sql_str = "DELETE FROM patient WHERE PatientID = " + patient_id
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    hospital.delete_one(sql_str)


def add_doctor(doctor_name, doctor_level, department):
    # sql语句： INSERT INTO doctor(DoctorName, DoctorLevel, Department) VALUES("doctor_name", doctor_level , department)
    sql_str = "INSERT INTO doctor(DoctorName, DoctorLevel, Department) VALUES('" + doctor_name + "', " \
              + doctor_level + ", " + department + ")"
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    hospital.insert_one(sql_str)


def delete_doctor(doctor_id):
    sql_str = "DELETE FROM doctor WHERE DoctorNumber = " + doctor_id
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    hospital.delete_one(sql_str)


def show_all_doctor():
    result_page = Tk()
    result_page.title('查询结果')  # 给窗口命名
    result_page.geometry('400x500')
    # sql语句：SELECT doctor.DoctorNumber, doctor.DoctorName, department.DepartmentName， doctorlevel.LevelName
    #   FROM doctor, doctorlevel, department WHERE doctor.Department = department.DepartmentNumber
    # 	AND doctor.DoctorLevel = doctorlevel.LevelNumber  ORDER BY doctor.DoctorNumber ASC
    sql_str = 'SELECT doctor.DoctorNumber, doctor.DoctorName, department.DepartmentName, doctorlevel.LevelName ' \
              'FROM doctor, doctorlevel, department WHERE doctor.Department = department.DepartmentNumber ' \
              'AND doctor.DoctorLevel = doctorlevel.LevelNumber  ORDER BY doctor.DoctorNumber ASC'
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    result = hospital.search_all(sql_str)
    result_txt = Text(result_page)
    result_txt.insert(END, "职工号\t姓名\t科室\t职称\n")
    for i in result:
        for j in i:
            result_txt.insert(END, j)
            result_txt.insert(END, "\t")
        result_txt.insert(END, "\n")
    result_txt.place(relx=0.05, rely=0.05, relwidth=0.9, relheight=0.9)

    result_page.mainloop()


def add_medicine(medicine_name, price):
    # sql语句： INSERT INTO medicine(MedicineName, Price) VALUES("medicine_name", price)
    sql_str = "INSERT INTO medicine(MedicineName, Price) VALUES('" + medicine_name + "', " + price + ")"
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    hospital.insert_one(sql_str)


def delete_medicine(medicine_id):
    sql_str = "DELETE FROM medicine WHERE MedicineNumber = " + medicine_id
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    hospital.delete_one(sql_str)


def add_ward(ward_number, capacity, department):
    # sql语句： INSERT INTO ward VALUES(ward_number, capacity, department, capacity)
    sql_str = "INSERT INTO ward VALUES(" + ward_number + ", " + capacity + ", " + department + ", " + capacity + ")"
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    hospital.insert_one(sql_str)


def delete_ward(ward_number):
    sql_str = "DELETE FROM ward WHERE WardNumber = " + ward_number
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    hospital.delete_one(sql_str)


def set_head(department_name, doctor_id):
    # sql语句：UPDATE department SET DepartmentHead = doctor_id WHERE DepartmentName = 'department_name'
    sql_str = "UPDATE department SET DepartmentHead = " + doctor_id + " WHERE DepartmentName = '" + department_name + "'"
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    hospital.updata_one(sql_str)


def update_medicine(medicine_name, price):
    # sql语句：UPDATE medicine SET Price = price WHERE MedicineName = 'medicine_name'
    sql_str = "UPDATE medicine SET Price = " + price + " WHERE MedicineNumber = '" + medicine_name + "'"
    hospital = ConnectSQL.MysqlConn()
    hospital.__init__()
    hospital.updata_one(sql_str)
