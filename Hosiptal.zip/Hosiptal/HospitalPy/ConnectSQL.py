# connect_db：连接数据库，并操作数据库

import pymysql


class MysqlConn:

    def __init__(self) -> object:
        # 创建一个连接数据库的对象
        self.conn = pymysql.connect(
            host='localhost',  # 连接的数据库服务器主机名
            port=3306,  # 数据库端口号
            user='root',  # 数据库登录用户名
            passwd='123456',
            db='hospital',  # 数据库名称
            charset='utf8'  # 连接编码
        )
        # 使用cursor()方法创建一个游标对象，用于操作数据库
        self.cur = self.conn.cursor()

    # 查询所有数据
    def search_all(self, sql):
        self.cur.execute(sql)
        result = self.cur.fetchall()  # 显示所有结果
        self.conn.close()
        return result

    # 更新SQL
    def updata_one(self, sql):
        try:
            self.cur.execute(sql)  # 执行sql
            self.conn.commit()  # 增删改操作完数据库后，需要执行提交操作
        except:
            # 发生错误时回滚
            self.conn.rollback()
        self.conn.close()  # 记得关闭数据库连接

    # 插入SQL
    def insert_one(self, sql):
        try:
            self.cur.execute(sql)  # 执行sql
            self.conn.commit()  # 增删改操作完数据库后，需要执行提交操作
        except:
            # 发生错误时回滚
            self.conn.rollback()
        self.conn.close()

    # 删除sql
    def delete_one(self, sql):
        try:
            self.cur.execute(sql)  # 执行sql
            self.conn.commit()  # 增删改操作完数据库后，需要执行提交操作
        except:
            # 发生错误时回滚
            self.conn.rollback()
        self.conn.close()

    # 调用用药的存储过程
    def call_use_medicine(self, patient, medicine):
        try:
            self.cur.callproc('UseMedicine', args=(patient, medicine))  # 调用存储过程
            self.conn.commit()  # 执行提交操作
        except:
            # 发生错误时回滚
            self.conn.rollback()
        self.conn.close()
