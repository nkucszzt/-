/*
 Navicat Premium Data Transfer

 Source Server         : LTX
 Source Server Type    : MySQL
 Source Server Version : 80029
 Source Host           : localhost:3306
 Source Schema         : hospital

 Target Server Type    : MySQL
 Target Server Version : 80029
 File Encoding         : 65001

 Date: 30/5/2024 10:57:50
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for department
-- ----------------------------
DROP TABLE IF EXISTS `department`;
CREATE TABLE `department`  (
  `DepartmentNumber` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `DepartmentName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `DepartmentHead` int(0) UNSIGNED NOT NULL,
  PRIMARY KEY (`DepartmentNumber`) USING BTREE,
  INDEX `head`(`DepartmentHead`) USING BTREE,
  CONSTRAINT `departmenthead` FOREIGN KEY (`DepartmentHead`) REFERENCES `doctor` (`DoctorNumber`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 28 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of department
-- ----------------------------
INSERT INTO `department` VALUES (1, '门诊', 1);
INSERT INTO `department` VALUES (2, '外科', 30);
INSERT INTO `department` VALUES (3, '内科', 2);
INSERT INTO `department` VALUES (4, '眼科', 16);
INSERT INTO `department` VALUES (5, '骨科', 17);
INSERT INTO `department` VALUES (6, '口腔科', 26);
INSERT INTO `department` VALUES (7, '耳鼻喉科', 4);
INSERT INTO `department` VALUES (8, '妇产科', 20);
INSERT INTO `department` VALUES (9, '皮肤科', 21);
INSERT INTO `department` VALUES (10, '传染科', 11);
INSERT INTO `department` VALUES (11, '中医科', 23);
INSERT INTO `department` VALUES (12, '肿瘤科', 12);
INSERT INTO `department` VALUES (13, '儿科', 29);

-- ----------------------------
-- Table structure for doctor
-- ----------------------------
DROP TABLE IF EXISTS `doctor`;
CREATE TABLE `doctor`  (
  `DoctorNumber` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `DoctorName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `DoctorLevel` int(0) UNSIGNED NULL DEFAULT NULL,
  `Department` int(0) UNSIGNED NOT NULL,
  PRIMARY KEY (`DoctorNumber`) USING BTREE,
  INDEX `level`(`DoctorLevel`) USING BTREE,
  INDEX `doctordepartment`(`Department`) USING BTREE,
  CONSTRAINT `doctordepartment` FOREIGN KEY (`Department`) REFERENCES `department` (`DepartmentNumber`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `level` FOREIGN KEY (`DoctorLevel`) REFERENCES `doctorlevel` (`LevelNumber`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 64 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of doctor
-- ----------------------------
INSERT INTO `doctor` VALUES (1, '无', 1, 1);
INSERT INTO `doctor` VALUES (2, '张二', 4, 3);
INSERT INTO `doctor` VALUES (3, '张三', 3, 5);
INSERT INTO `doctor` VALUES (4, '张四', 4, 7);
INSERT INTO `doctor` VALUES (5, '张五', 3, 9);
INSERT INTO `doctor` VALUES (6, '张六', 2, 11);
INSERT INTO `doctor` VALUES (7, '张七', 1, 2);
INSERT INTO `doctor` VALUES (8, '张八', 1, 4);
INSERT INTO `doctor` VALUES (9, '张九', 2, 6);
INSERT INTO `doctor` VALUES (10, '张十', 3, 8);
INSERT INTO `doctor` VALUES (11, '李一', 4, 10);
INSERT INTO `doctor` VALUES (12, '李二', 3, 12);
INSERT INTO `doctor` VALUES (13, '李三', 2, 13);
INSERT INTO `doctor` VALUES (14, '李四', 1, 2);
INSERT INTO `doctor` VALUES (15, '李五', 1, 3);
INSERT INTO `doctor` VALUES (16, '李六', 3, 4);
INSERT INTO `doctor` VALUES (17, '李七', 4, 5);
INSERT INTO `doctor` VALUES (18, '李八', 3, 6);
INSERT INTO `doctor` VALUES (19, '李九', 3, 7);
INSERT INTO `doctor` VALUES (20, '李十', 4, 8);
INSERT INTO `doctor` VALUES (21, '王一', 4, 9);
INSERT INTO `doctor` VALUES (22, '王二', 3, 10);
INSERT INTO `doctor` VALUES (23, '王三', 3, 11);
INSERT INTO `doctor` VALUES (24, '王四', 2, 12);
INSERT INTO `doctor` VALUES (25, '王五', 2, 3);
INSERT INTO `doctor` VALUES (26, '王六', 3, 6);
INSERT INTO `doctor` VALUES (27, '王七', 1, 9);
INSERT INTO `doctor` VALUES (28, '王八', 1, 12);
INSERT INTO `doctor` VALUES (29, '王九', 4, 13);
INSERT INTO `doctor` VALUES (30, '王十', 4, 2);
INSERT INTO `doctor` VALUES (31, '张一', 1, 13);

-- ----------------------------
-- Table structure for doctorlevel
-- ----------------------------
DROP TABLE IF EXISTS `doctorlevel`;
CREATE TABLE `doctorlevel`  (
  `LevelNumber` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `LevelName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`LevelNumber`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of doctorlevel
-- ----------------------------
INSERT INTO `doctorlevel` VALUES (1, '住院医师');
INSERT INTO `doctorlevel` VALUES (2, '主治医师');
INSERT INTO `doctorlevel` VALUES (3, '副主任医师');
INSERT INTO `doctorlevel` VALUES (4, '主任医师');

-- ----------------------------
-- Table structure for inpatient
-- ----------------------------
DROP TABLE IF EXISTS `inpatient`;
CREATE TABLE `inpatient`  (
  `PatientID` int(0) UNSIGNED NOT NULL,
  `WardNumber` int(0) UNSIGNED NOT NULL,
  PRIMARY KEY (`PatientID`) USING BTREE,
  INDEX `PatientWard`(`WardNumber`) USING BTREE,
  CONSTRAINT `InpatientID` FOREIGN KEY (`PatientID`) REFERENCES `patient` (`PatientID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `PatientWard` FOREIGN KEY (`WardNumber`) REFERENCES `ward` (`WardNumber`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of inpatient
-- ----------------------------
INSERT INTO `inpatient` VALUES (333333, 0);
INSERT INTO `inpatient` VALUES (555555, 0);
INSERT INTO `inpatient` VALUES (666666, 0);
INSERT INTO `inpatient` VALUES (100001, 101);
INSERT INTO `inpatient` VALUES (100002, 201);
INSERT INTO `inpatient` VALUES (200001, 202);
INSERT INTO `inpatient` VALUES (100003, 303);

-- ----------------------------
-- Table structure for medicine
-- ----------------------------
DROP TABLE IF EXISTS `medicine`;
CREATE TABLE `medicine`  (
  `MedicineNumber` int(0) UNSIGNED NOT NULL AUTO_INCREMENT,
  `MedicineName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Price` float(10, 2) UNSIGNED NOT NULL,
  PRIMARY KEY (`MedicineNumber`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of medicine
-- ----------------------------
INSERT INTO `medicine` VALUES (1, '藿香正气水', 10.00);
INSERT INTO `medicine` VALUES (3, '板蓝根', 5.00);
INSERT INTO `medicine` VALUES (7, '安定', 30.00);
INSERT INTO `medicine` VALUES (8, '晕海宁', 18.00);
INSERT INTO `medicine` VALUES (9, '扑热息痛', 32.00);
INSERT INTO `medicine` VALUES (10, '阿司匹林', 35.00);
INSERT INTO `medicine` VALUES (11, '咳必清', 40.00);
INSERT INTO `medicine` VALUES (12, '必咳平', 41.00);
INSERT INTO `medicine` VALUES (13, '复方甘草合剂', 60.00);
INSERT INTO `medicine` VALUES (14, '氨茶碱', 36.00);
INSERT INTO `medicine` VALUES (15, '舒喘灵', 30.00);
INSERT INTO `medicine` VALUES (16, '云南白药', 80.00);

-- ----------------------------
-- Table structure for patient
-- ----------------------------
DROP TABLE IF EXISTS `patient`;
CREATE TABLE `patient`  (
  `PatientID` int(0) UNSIGNED NOT NULL,
  `PatientName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `PatientAge` int(0) UNSIGNED NOT NULL,
  `PatientCost` float(10, 2) UNSIGNED NOT NULL,
  PRIMARY KEY (`PatientID`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of patient
-- ----------------------------
INSERT INTO `patient` VALUES (100001, '小明', 10, 60.00);
INSERT INTO `patient` VALUES (100002, '小红', 15, 210.00);
INSERT INTO `patient` VALUES (100003, '小亮', 18, 100.00);
INSERT INTO `patient` VALUES (200001, '甲一', 20, 123.00);
INSERT INTO `patient` VALUES (333333, '张三', 33, 0.00);
INSERT INTO `patient` VALUES (555555, '小五', 55, 0.00);
INSERT INTO `patient` VALUES (666666, '小六', 30, 0.00);

-- ----------------------------
-- Table structure for patientdoctor
-- ----------------------------
DROP TABLE IF EXISTS `patientdoctor`;
CREATE TABLE `patientdoctor`  (
  `PatientID` int(0) UNSIGNED NOT NULL,
  `DoctorID` int(0) UNSIGNED NOT NULL,
  PRIMARY KEY (`PatientID`) USING BTREE,
  INDEX `DID`(`DoctorID`) USING BTREE,
  CONSTRAINT `DID` FOREIGN KEY (`DoctorID`) REFERENCES `doctor` (`DoctorNumber`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `PID` FOREIGN KEY (`PatientID`) REFERENCES `patient` (`PatientID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of patientdoctor
-- ----------------------------
INSERT INTO `patientdoctor` VALUES (100003, 1);
INSERT INTO `patientdoctor` VALUES (333333, 1);
INSERT INTO `patientdoctor` VALUES (555555, 1);
INSERT INTO `patientdoctor` VALUES (100001, 6);
INSERT INTO `patientdoctor` VALUES (100002, 10);
INSERT INTO `patientdoctor` VALUES (666666, 10);
INSERT INTO `patientdoctor` VALUES (200001, 22);

-- ----------------------------
-- Table structure for ward
-- ----------------------------
DROP TABLE IF EXISTS `ward`;
CREATE TABLE `ward`  (
  `WardNumber` int(0) UNSIGNED NOT NULL,
  `Capacity` int(0) UNSIGNED NOT NULL,
  `Department` int(0) UNSIGNED NOT NULL,
  `rest` int(0) NOT NULL,
  PRIMARY KEY (`WardNumber`) USING BTREE,
  INDEX `department`(`Department`) USING BTREE,
  CONSTRAINT `department` FOREIGN KEY (`Department`) REFERENCES `department` (`DepartmentNumber`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ward
-- ----------------------------
INSERT INTO `ward` VALUES (0, 100000, 1, 100000);
INSERT INTO `ward` VALUES (101, 4, 13, 4);
INSERT INTO `ward` VALUES (102, 4, 13, 4);
INSERT INTO `ward` VALUES (103, 4, 13, 4);
INSERT INTO `ward` VALUES (104, 4, 13, 4);
INSERT INTO `ward` VALUES (105, 4, 13, 4);
INSERT INTO `ward` VALUES (106, 4, 2, 4);
INSERT INTO `ward` VALUES (107, 4, 2, 4);
INSERT INTO `ward` VALUES (108, 4, 2, 4);
INSERT INTO `ward` VALUES (109, 4, 2, 4);
INSERT INTO `ward` VALUES (110, 4, 2, 4);
INSERT INTO `ward` VALUES (111, 4, 3, 4);
INSERT INTO `ward` VALUES (112, 4, 3, 4);
INSERT INTO `ward` VALUES (113, 4, 4, 4);
INSERT INTO `ward` VALUES (114, 4, 4, 4);
INSERT INTO `ward` VALUES (115, 4, 5, 4);
INSERT INTO `ward` VALUES (116, 4, 5, 4);
INSERT INTO `ward` VALUES (117, 4, 6, 4);
INSERT INTO `ward` VALUES (118, 4, 6, 4);
INSERT INTO `ward` VALUES (119, 4, 7, 4);
INSERT INTO `ward` VALUES (120, 4, 7, 4);
INSERT INTO `ward` VALUES (201, 3, 8, 3);
INSERT INTO `ward` VALUES (202, 3, 8, 3);
INSERT INTO `ward` VALUES (203, 3, 9, 3);
INSERT INTO `ward` VALUES (204, 3, 9, 3);
INSERT INTO `ward` VALUES (205, 3, 10, 3);
INSERT INTO `ward` VALUES (301, 2, 10, 2);
INSERT INTO `ward` VALUES (302, 2, 11, 2);
INSERT INTO `ward` VALUES (303, 2, 11, 2);
INSERT INTO `ward` VALUES (304, 2, 12, 2);
INSERT INTO `ward` VALUES (305, 2, 12, 2);
INSERT INTO `ward` VALUES (401, 1, 3, 1);
INSERT INTO `ward` VALUES (402, 1, 4, 1);
INSERT INTO `ward` VALUES (403, 1, 5, 1);
INSERT INTO `ward` VALUES (404, 1, 6, 1);
INSERT INTO `ward` VALUES (405, 1, 7, 1);
INSERT INTO `ward` VALUES (501, 2, 10, 2);

-- ----------------------------
-- View structure for patientview
-- ----------------------------
DROP VIEW IF EXISTS `patientview`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `patientview` AS select `patient`.`PatientID` AS `ID`,`patient`.`PatientName` AS `Name`,`patient`.`PatientAge` AS `Age`,`patient`.`PatientCost` AS `Cost`,`inpatient`.`WardNumber` AS `Ward`,`doctor`.`DoctorName` AS `Doctor` from (((`patient` join `doctor`) join `patientdoctor` on(((`patientdoctor`.`DoctorID` = `doctor`.`DoctorNumber`) and (`patientdoctor`.`PatientID` = `patient`.`PatientID`)))) join `inpatient` on((`inpatient`.`PatientID` = `patient`.`PatientID`)));

-- ----------------------------
-- Procedure structure for UseMedicine
-- ----------------------------
DROP PROCEDURE IF EXISTS `UseMedicine`;
delimiter ;;
CREATE PROCEDURE `UseMedicine`(IN `PID` int,IN `MID` int)
BEGIN
	#Routine body goes here...
	DECLARE addcost FLOAT ;
	SET addcost = (SELECT Price FROM medicine WHERE MedicineNumber = MID);
	UPDATE patient SET PatientCost = (PatientCost + addcost) WHERE patientID = PID;
END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;

DELIMITER //

CREATE TRIGGER `trig_addpatient` 
AFTER INSERT ON `patient` 
FOR EACH ROW 
BEGIN
  IF NEW.PatientID >= 100000 THEN
    IF NEW.PatientID <= 999999 THEN
      INSERT INTO patientdoctor (PatientID, DoctorID) VALUES (NEW.PatientID, 1);
      INSERT INTO inpatient (PatientID, WardNumber) VALUES (NEW.PatientID, 0);
    END IF;
  END IF;
END;
//